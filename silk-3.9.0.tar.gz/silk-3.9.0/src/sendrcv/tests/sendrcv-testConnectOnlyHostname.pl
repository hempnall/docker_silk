#! /usr/bin/perl -w
#
#

use strict;
use SiLKTests;

do $SiLKTests::srcdir."/tests/sendrcv-one-daemon.pm";
exit 1;
